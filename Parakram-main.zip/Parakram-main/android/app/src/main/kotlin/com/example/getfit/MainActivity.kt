package com.example.getfit

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
