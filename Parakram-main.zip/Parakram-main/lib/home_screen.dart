import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:marquee/marquee.dart';
import 'package:getfit/tabs/mental_tab.dart';
import 'package:getfit/tabs/physical_tab.dart';
import 'package:getfit/tabs/social_tab.dart';

// ---------------- HOME SCREEN ----------------
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late PageController _pageController;
  late Timer _autoSlideTimer;
  bool _isDarkMode = false;
  double _currentPage = 0;

  final Map<String, dynamic> _userData = {
    "image": "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
    "name": "Ayush",
    "goal": "Personality development",
  };

  final List<Map<String, dynamic>> _menuItems = [
    {"icon": Icons.person, "label": "My Profile"},
    {"icon": Icons.settings, "label": "Settings"},
    {"icon": Icons.show_chart, "label": "Progress"},
    {"icon": Icons.emoji_events, "label": "Achievements"},
    {"icon": Icons.flag, "label": "Goals"},
  ];

  List<Map<String, dynamic>> get _carouselItems {
    return [
      {
        "label": "Physical Enhancement",
        "icon": Icons.fitness_center,
        "image":
        "https://wallpapers.com/images/hd/4k-military-5k9pstf7bn3mun6b.jpg",
        "gradient": _isDarkMode
            ? [Colors.red.shade900, Colors.orange.shade900]
            : [Colors.redAccent, Colors.orangeAccent],
        "page": const PhysicalTab(),
      },
      {
        "label": "Mental Enhancement",
        "icon": Icons.psychology,
        "image":
        "https://1.bp.blogspot.com/-MnGg4cWgmP0/YMs_4NIkUDI/AAAAAAAABgs/mm6bEMF8CgoabP-sy4rM71YFLymDt_OGQCLcBGAsYHQ/w640-h318/1.JPG",
        "gradient": _isDarkMode
            ? [Colors.blue.shade900, Colors.lightBlue.shade900]
            : [Colors.blueAccent, Colors.lightBlueAccent],
        "page": const MentalTab(),
      },
      {
        "label": "Social Enhancement",
        "icon": Icons.people,
        "image":
        "https://cdn.siasat.com/wp-content/uploads/2023/06/2023_6img10_Jun_2023_PTI06_10_2023_000067B-scaled.jpg",
        "gradient": _isDarkMode
            ? [Colors.green.shade900, Colors.teal.shade900]
            : [Colors.greenAccent, Colors.tealAccent],
        "page": const SocialTab(),
      },
    ];
  }

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.75);
    _pageController.addListener(() {
      setState(() {
        _currentPage = _pageController.page ?? 0;
      });
    });

    // Auto-slide every 4 seconds
    _autoSlideTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      int nextPage = (_currentPage.round() + 1) % _carouselItems.length;
      _pageController.animateToPage(
        nextPage,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _autoSlideTimer.cancel();
    _pageController.dispose();
    super.dispose();
  }

  void _navigate(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  void _onMenuItemTap(int index) {
    String label = _menuItems[index]['label'] as String;
    if (label == "Settings") {
      _showSettingsDialog();
    } else if (label == "My Profile") {
      _navigate(context, ProfileScreen(userData: _userData));
    }
  }

  void _showSettingsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _isDarkMode ? Colors.grey[900] : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          "Settings",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: _isDarkMode ? Colors.white : Colors.black,
          ),
        ),
        content: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Night Mode",
              style: GoogleFonts.poppins(
                fontSize: 16,
                color: _isDarkMode ? Colors.white70 : Colors.black87,
              ),
            ),
            Switch(
              value: _isDarkMode,
              onChanged: (value) {
                setState(() => _isDarkMode = value);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
      _isDarkMode ? Colors.grey.shade900 : Colors.deepPurple[50],
      appBar: AppBar(
        title: SizedBox(
          height: 30,
          child: Marquee(
            text: "⚡ Reshape yourself as a Future Soldier ⚡",
            style: GoogleFonts.orbitron(
              fontWeight: FontWeight.bold,
              fontSize: 20,
              color: Colors.white,
              letterSpacing: 2,
              shadows: [
                Shadow(
                  blurRadius: 12,
                  color: Colors.cyanAccent.withOpacity(0.8),
                  offset: const Offset(0, 0),
                ),
              ],
            ),
            scrollAxis: Axis.horizontal,
            crossAxisAlignment: CrossAxisAlignment.center,
            blankSpace: 60,
            velocity: 40,
            pauseAfterRound: const Duration(seconds: 1),
            startPadding: 20,
            accelerationDuration: const Duration(seconds: 1),
            decelerationDuration: const Duration(milliseconds: 500),
          ),
        ),
        centerTitle: true,
        backgroundColor:
        _isDarkMode ? Colors.deepPurple.shade700 : Colors.deepPurpleAccent,
        elevation: 6,
        leading: GestureDetector(
          onTap: () => _navigate(context, ProfileScreen(userData: _userData)),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Hero(
              tag: "profileAvatar",
              child: CircleAvatar(
                backgroundImage: NetworkImage(_userData["image"] as String),
              ),
            ),
          ),
        ),
        actions: [
          GestureDetector(
            onTap: () => _navigate(context, const PremiumPage()),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.orangeAccent,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  const BoxShadow(
                      color: Colors.black26, blurRadius: 4, offset: Offset(0, 2))
                ],
              ),
              child: Row(
                children: [
                  const Icon(Icons.star, color: Colors.white, size: 18),
                  const SizedBox(width: 5),
                  Text(
                    "Subscribe",
                    style: GoogleFonts.poppins(
                        color: Colors.white, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ),
          PopupMenuButton<int>(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            color: _isDarkMode ? Colors.grey[850] : Colors.white,
            onSelected: _onMenuItemTap,
            itemBuilder: (context) => _menuItems
                .map((item) => PopupMenuItem<int>(
              value: _menuItems.indexOf(item),
              child: Row(
                children: [
                  Icon(item['icon'],
                      color: Colors.deepPurpleAccent),
                  const SizedBox(width: 10),
                  Text(item['label'] as String,
                      style: GoogleFonts.poppins()),
                ],
              ),
            ))
                .toList(),
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          Expanded(
            child: PageView.builder(
              controller: _pageController,
              physics: const BouncingScrollPhysics(),
              itemCount: _carouselItems.length,
              itemBuilder: (context, index) {
                double distance = (index - _currentPage).abs();
                double scale = (1 - distance * 0.2).clamp(0.8, 1.0);
                double opacity = (1 - distance * 0.3).clamp(0.6, 1.0);

                final item = _carouselItems[index];
                bool isActive = distance < 0.5;

                return Opacity(
                  opacity: opacity,
                  child: Transform.scale(
                    scale: scale,
                    child: _buildCarouselCard(item, isActive),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCarouselCard(Map<String, dynamic> item, bool isActive) {
    return GestureDetector(
      onTap: () => _navigate(context, item['page'] as Widget),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: isActive ? Colors.black38 : Colors.black26,
              blurRadius: isActive ? 12 : 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.network(item['image'] as String, fit: BoxFit.cover),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.black.withOpacity(isActive ? 0.2 : 0.4),
                      Colors.black.withOpacity(isActive ? 0.5 : 0.7),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(item['icon'],
                        size: isActive ? 70 : 50, color: Colors.white),
                    const SizedBox(height: 12),
                    Text(
                      item['label'] as String,
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: isActive ? 22 : 18,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------- PROFILE SCREEN ----------------
class ProfileScreen extends StatelessWidget {
  final Map<String, dynamic> userData;
  const ProfileScreen({super.key, required this.userData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildProfileHeader(),
            const SizedBox(height: 20),
            _buildInfoCards(),
            const SizedBox(height: 20),
            _buildGoalSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileHeader() {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          height: 200,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
                colors: [Colors.deepPurpleAccent, Colors.purpleAccent]),
            borderRadius:
            BorderRadius.vertical(bottom: Radius.circular(40)),
          ),
        ),
        Positioned(
          bottom: -50,
          left: 0,
          right: 0,
          child: Hero(
            tag: "profileAvatar",
            child: CircleAvatar(
              radius: 60,
              backgroundColor: Colors.white,
              backgroundImage: NetworkImage(userData["image"] as String),
            ),
          ),
        ),
        Positioned(
          top: 50,
          left: 20,
          child: Hero(
            tag: "profileName",
            child: Text(
              userData["name"] as String,
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInfoCards() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _infoCard("Age", "21 yrs"),
          _infoCard("Weight", "62 kg"),
          _infoCard("Height", "175 cm"),
        ],
      ),
    );
  }

  Widget _infoCard(String label, String value) {
    return Container(
      width: 100,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.9),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 6)],
      ),
      child: Column(
        children: [
          Text(label,
              style:
              GoogleFonts.poppins(fontSize: 14, color: Colors.grey)),
          const SizedBox(height: 4),
          Text(value,
              style: GoogleFonts.poppins(
                  fontSize: 16, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildGoalSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
              colors: [Colors.deepPurpleAccent, Colors.purpleAccent]),
          borderRadius: BorderRadius.circular(16),
          boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 8)],
        ),
        child: Row(
          children: [
            const Icon(Icons.flag, color: Colors.white, size: 28),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                userData["goal"] as String,
                style: GoogleFonts.poppins(
                    color: Colors.white, fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- PREMIUM PAGE ----------------
class PremiumPage extends StatelessWidget {
  const PremiumPage({super.key});

  @override
  Widget build(BuildContext context) {
    final features = [
      {
        "icon": Icons.star,
        "title": "Exclusive Workouts",
        "description": "Unlock advanced physical and mental exercises."
      },
      {
        "icon": Icons.person,
        "title": "Get a Personal Mentor",
        "description": "Guidance from a retired Army Veteran."
      },
      {
        "icon": Icons.book,
        "title": "Spiritual Guidance",
        "description": "Read rare scriptures and spiritual texts."
      },
      {
        "icon": Icons.menu_book,
        "title": "Access Full Notes",
        "description": "Detailed study material and learning resources."
      },
      {
        "icon": Icons.group,
        "title": "Community Access",
        "description": "Join private groups and discussions."
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Premium Features",
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.deepPurpleAccent,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ...features.map((f) => _premiumFeatureCard(
              f["icon"] as IconData, f["title"] as String, f["description"] as String)),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Proceeding to Payment...")),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orangeAccent,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            child: Text(
              "Proceed to Payment",
              style: GoogleFonts.poppins(
                  fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  Widget _premiumFeatureCard(IconData icon, String title, String description) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Colors.deepPurpleAccent, Colors.purpleAccent],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 8)],
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: Colors.white.withOpacity(0.2),
            child: Icon(icon, color: Colors.white, size: 30),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.poppins(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.white)),
                const SizedBox(height: 6),
                Text(description,
                    style: GoogleFonts.poppins(
                        fontSize: 14, color: Colors.white70)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
