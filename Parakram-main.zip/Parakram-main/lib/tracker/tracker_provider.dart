import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';

// ---------------- Tracker Provider ----------------
class TrackerProvider extends ChangeNotifier {
  final List<Map<String, dynamic>> _records = [];
  List<Map<String, dynamic>> get records => _records;

  void addRecord({
    required String exercise,
    required int duration,
    required int weightsUsed,
    required int reps,
    required int targetReps,
    required DateTime day,
  }) {
    _records.add({
      "exercise": exercise,
      "duration": duration,
      "weightsUsed": weightsUsed,
      "reps": reps,
      "targetReps": targetReps,
      "day": day,
    });
    notifyListeners();
  }

  double get completionPercentage {
    if (_records.isEmpty) return 0.0;
    double totalTarget = _records.fold(0, (sum, e) => sum + e["targetReps"]);
    double totalReps = _records.fold(0, (sum, e) => sum + e["reps"]);
    return totalTarget == 0 ? 0.0 : (totalReps / totalTarget) * 100;
  }
}

// ---------------- Home Screen ----------------
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late PageController _pageController;
  late Timer _autoSlideTimer;
  bool _isDarkMode = false;
  double _currentPage = 0;

  final Map<String, dynamic> _userData = {
    "image": "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
    "name": "Ayush",
    "goal": "Personality development",
  };

  final List<Map<String, dynamic>> _menuItems = [
    {"icon": Icons.person, "label": "My Profile"},
    {"icon": Icons.settings, "label": "Settings"},
    {"icon": Icons.show_chart, "label": "Progress"},
    {"icon": Icons.emoji_events, "label": "Achievements"},
    {"icon": Icons.flag, "label": "Goals"},
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.75);
    _pageController.addListener(() {
      setState(() {
        _currentPage = _pageController.page ?? 0;
      });
    });

    _autoSlideTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      int nextPage = (_currentPage.round() + 1) % 3;
      _pageController.animateToPage(
        nextPage,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _autoSlideTimer.cancel();
    _pageController.dispose();
    super.dispose();
  }

  void _navigate(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  void _onMenuItemTap(int index) {
    String label = _menuItems[index]['label'] as String;
    if (label == "Settings") {
      _showSettingsDialog();
    } else if (label == "My Profile") {
      _navigate(context, ProfileScreen(userData: _userData));
    } else if (label == "Progress") {
      _navigate(context, const ProgressPage());
    }
  }

  void _showSettingsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _isDarkMode ? Colors.grey[900] : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          "Settings",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: _isDarkMode ? Colors.white : Colors.black,
          ),
        ),
        content: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Night Mode",
              style: GoogleFonts.poppins(
                fontSize: 16,
                color: _isDarkMode ? Colors.white70 : Colors.black87,
              ),
            ),
            Switch(
              value: _isDarkMode,
              onChanged: (value) {
                setState(() => _isDarkMode = value);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _isDarkMode ? Colors.grey.shade900 : Colors.deepPurple[50],
      appBar: AppBar(
        title: Text(
          "Get Fit",
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 22),
        ),
        centerTitle: true,
        backgroundColor: _isDarkMode ? Colors.deepPurple.shade700 : Colors.deepPurpleAccent,
        elevation: 6,
        leading: GestureDetector(
          onTap: () => _navigate(context, ProfileScreen(userData: _userData)),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Hero(
              tag: "profileAvatar",
              child: CircleAvatar(
                backgroundImage: NetworkImage(_userData["image"] as String),
              ),
            ),
          ),
        ),
        actions: [
          PopupMenuButton<int>(
            icon: Icon(Icons.more_vert, color: Colors.white),
            color: _isDarkMode ? Colors.grey[850] : Colors.white,
            onSelected: _onMenuItemTap,
            itemBuilder: (context) => _menuItems
                .map((item) => PopupMenuItem<int>(
              value: _menuItems.indexOf(item),
              child: Row(
                children: [
                  Icon(item['icon'], color: Colors.deepPurpleAccent),
                  const SizedBox(width: 10),
                  Text(item['label'] as String, style: GoogleFonts.poppins()),
                ],
              ),
            ))
                .toList(),
          ),
        ],
      ),
      body: Center(
        child: Text(
          "Welcome, ${_userData['name']}",
          style: GoogleFonts.poppins(fontSize: 22),
        ),
      ),
    );
  }
}

// ---------------- Progress Page ----------------
class ProgressPage extends StatefulWidget {
  const ProgressPage({super.key});

  @override
  State<ProgressPage> createState() => _ProgressPageState();
}

class _ProgressPageState extends State<ProgressPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _exerciseController = TextEditingController();
  final TextEditingController _durationController = TextEditingController();
  final TextEditingController _weightsController = TextEditingController();
  final TextEditingController _repsController = TextEditingController();
  final TextEditingController _targetRepsController = TextEditingController();
  DateTime _selectedDay = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Workout Progress")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Column(
                children: [
                  _buildTextField("Exercise", _exerciseController),
                  _buildTextField("Duration (min)", _durationController, isNumber: true),
                  _buildTextField("Weights Used", _weightsController, isNumber: true),
                  _buildTextField("Reps", _repsController, isNumber: true),
                  _buildTextField("Target Reps", _targetRepsController, isNumber: true),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Text("Day: ${_selectedDay.toLocal()}".split(' ')[0]),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: _pickDate,
                        child: const Text("Select Day"),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _addRecord,
                    child: const Text("Add Record"),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Consumer<TrackerProvider>(
              builder: (context, tracker, _) {
                double completion = tracker.completionPercentage;
                return Column(
                  children: [
                    SizedBox(
                      height: 200,
                      child: PieChart(
                        PieChartData(
                          sections: [
                            PieChartSectionData(
                              color: Colors.green,
                              value: completion,
                              title: "${completion.toStringAsFixed(1)}%",
                              radius: 60,
                              titleStyle: const TextStyle(color: Colors.white),
                            ),
                            PieChartSectionData(
                              color: Colors.grey,
                              value: 100 - completion,
                              title: "",
                              radius: 60,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: tracker.records.length,
                      itemBuilder: (context, index) {
                        final rec = tracker.records[index];
                        return ListTile(
                          title: Text("${rec['exercise']}"),
                          subtitle: Text(
                              "Reps: ${rec['reps']}/${rec['targetReps']}, Duration: ${rec['duration']} min, Weights: ${rec['weightsUsed']}, Day: ${rec['day'].toLocal().toString().split(' ')[0]}"),
                        );
                      },
                    )
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller,
      {bool isNumber = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: TextFormField(
        controller: controller,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        validator: (val) => val == null || val.isEmpty ? "Required" : null,
      ),
    );
  }

  void _pickDate() async {
    DateTime? picked = await showDatePicker(
        context: context,
        initialDate: _selectedDay,
        firstDate: DateTime(2020),
        lastDate: DateTime(2100));
    if (picked != null) setState(() => _selectedDay = picked);
  }

  void _addRecord() {
    if (_formKey.currentState!.validate()) {
      Provider.of<TrackerProvider>(context, listen: false).addRecord(
        exercise: _exerciseController.text,
        duration: int.parse(_durationController.text),
        weightsUsed: int.parse(_weightsController.text),
        reps: int.parse(_repsController.text),
        targetReps: int.parse(_targetRepsController.text),
        day: _selectedDay,
      );
      _exerciseController.clear();
      _durationController.clear();
      _weightsController.clear();
      _repsController.clear();
      _targetRepsController.clear();
      setState(() {});
    }
  }
}

// ---------------- Profile Screen ----------------
class ProfileScreen extends StatelessWidget {
  final Map<String, dynamic> userData;
  const ProfileScreen({super.key, required this.userData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildProfileHeader(),
            const SizedBox(height: 20),
            _buildInfoCards(),
            const SizedBox(height: 20),
            _buildGoalSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileHeader() {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          height: 200,
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [Colors.deepPurpleAccent, Colors.purpleAccent]),
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(40)),
          ),
        ),
        Positioned(
          bottom: -50,
          left: 0,
          right: 0,
          child: Hero(
            tag: "profileAvatar",
            child: CircleAvatar(
              radius: 60,
              backgroundColor: Colors.white,
              backgroundImage: NetworkImage(userData["image"] as String),
            ),
          ),
        ),
        Positioned(
          top: 50,
          left: 20,
          child: Hero(
            tag: "profileName",
            child: Text(
              userData["name"] as String,
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInfoCards() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _infoCard("Age", "21 yrs"),
          _infoCard("Weight", "62 kg"),
          _infoCard("Height", "175 cm"),
        ],
      ),
    );
  }

  Widget _infoCard(String label, String value) {
    return Container(
      width: 100,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.9),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 6)],
      ),
      child: Column(
        children: [
          Text(label, style: GoogleFonts.poppins(fontSize: 14, color: Colors.grey)),
          const SizedBox(height: 4),
          Text(value, style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildGoalSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Colors.deepPurpleAccent, Colors.purpleAccent]),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 8)],
        ),
        child: Row(
          children: [
            const Icon(Icons.flag, color: Colors.white, size: 28),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                userData["goal"] as String,
                style: GoogleFonts.poppins(color: Colors.white, fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- Main ----------------
void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => TrackerProvider(),
      child: const MaterialApp(
        home: HomeScreen(),
      ),
    ),
  );
}
