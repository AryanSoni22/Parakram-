 import 'package:flutter/material.dart';

class TrackerProvider extends ChangeNotifier {
  final List<Map<String, dynamic>> _records = [];

  List<Map<String, dynamic>> get records => _records;

  void addRecord(String category, int value) {
    _records.add({
      "category": category,
      "value": value,
      "date": DateTime.now(),
    });
    notifyListeners();
  }
}


