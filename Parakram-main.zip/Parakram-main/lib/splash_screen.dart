import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:ui';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _lettersController;
  late List<Animation<Offset>> _letterAnimations;

  late AnimationController _transformController;
  late Animation<Offset> _transformOffset;
  late Animation<double> _transformFade;

  late AnimationController _subtitleController;
  late Animation<Offset> _subtitleOffset;
  late Animation<double> _subtitleFade;

  bool _showTransform = true;
  final String word = "PARAKRAM";

  // Carousel
  final PageController _pageController = PageController(viewportFraction: 0.85);
  int _currentPage = 0;
  late Timer _autoSlideTimer;

  final List<_CarouselButtonData> _carouselItems = [
    _CarouselButtonData("Login", Icons.login, [Colors.blue, Colors.blueAccent]),
    _CarouselButtonData(
        "Register", Icons.app_registration, [Colors.green, Colors.lightGreen]),
    _CarouselButtonData(
        "Guest", Icons.person_outline, [Colors.orange, Colors.deepOrange]),
  ];

  @override
  void initState() {
    super.initState();

    // Letters animation
    _lettersController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    final startOffsets = [
      const Offset(-3, 0),
      const Offset(0, -3),
      const Offset(3, 0),
      const Offset(0, 3),
      const Offset(-3, -3),
      const Offset(3, -3),
      const Offset(-3, 3),
      const Offset(3, 3),
    ];
    _letterAnimations = List.generate(word.length, (index) {
      return Tween<Offset>(
        begin: startOffsets[index % startOffsets.length],
        end: Offset.zero,
      ).animate(CurvedAnimation(
        parent: _lettersController,
        curve: Curves.easeOut,
      ));
    });
    _lettersController.forward();

    // Transform animation
    _transformController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );
    _transformOffset = Tween<Offset>(
      begin: const Offset(0, -1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _transformController,
      curve: Curves.easeOut,
    ));
    _transformFade = CurvedAnimation(
      parent: _transformController,
      curve: Curves.easeIn,
    );

    // Subtitle animation
    _subtitleController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );
    _subtitleOffset = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _subtitleController,
      curve: Curves.easeOut,
    ));
    _subtitleFade = CurvedAnimation(
      parent: _subtitleController,
      curve: Curves.easeIn,
    );

    // Sequence
    _transformController.forward();
    Future.delayed(const Duration(seconds: 2), () {
      setState(() => _showTransform = false);
      _subtitleController.forward();
    });

    // Auto-slide
    _autoSlideTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      _currentPage = (_currentPage + 1) % _carouselItems.length;
      _pageController.animateToPage(
        _currentPage,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _lettersController.dispose();
    _transformController.dispose();
    _subtitleController.dispose();
    _pageController.dispose();
    _autoSlideTimer.cancel();
    super.dispose();
  }

  void _goToHome() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  void _goToRegister() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const RegisterPage()),
    );
  }

  Widget _buildPremiumButton(_CarouselButtonData item, double width) {
    // Responsive scaling
    double buttonHeight = width * 0.18; // scales with screen width
    double fontSize = width * 0.05; // text adapts to screen
    double iconSize = width * 0.07;

    return GestureDetector(
      onTap: () {
        if (item.label == "Login" || item.label == "Guest") {
          _goToHome();
        } else if (item.label == "Register") {
          _goToRegister();
        }
      },
      child: AnimatedScale(
        scale: 1.0,
        duration: const Duration(milliseconds: 200),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
            child: Container(
              height: buttonHeight,
              padding: EdgeInsets.symmetric(horizontal: width * 0.05),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: item.gradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(18),
                boxShadow: [
                  BoxShadow(
                    color: item.gradient.last.withOpacity(0.5),
                    blurRadius: 14,
                    spreadRadius: 2,
                    offset: const Offset(2, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(width * 0.03),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.15),
                      border: Border.all(color: Colors.white.withOpacity(0.2)),
                    ),
                    child: Icon(item.icon, size: iconSize, color: Colors.white),
                  ),
                  SizedBox(width: width * 0.05),
                  Expanded(
                    child: Text(
                      item.label,
                      style: TextStyle(
                        fontSize: fontSize,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                  Icon(Icons.arrow_forward_ios,
                      size: width * 0.045, color: Colors.white70),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final double width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.network(
            'https://images.unsplash.com/photo-1575419268007-a9a5e6b1ce0b?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0',
            fit: BoxFit.cover,
          ),
          Container(color: Colors.black.withOpacity(0.4)),
          Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_showTransform)
                    FadeTransition(
                      opacity: _transformFade,
                      child: SlideTransition(
                        position: _transformOffset,
                        child: const Text(
                          "Transform Yourself",
                          style: TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w600,
                            color: Colors.lightBlueAccent,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: List.generate(word.length, (index) {
                      return SlideTransition(
                        position: _letterAnimations[index],
                        child: Text(
                          word[index],
                          style: const TextStyle(
                            fontSize: 40,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            letterSpacing: 2,
                          ),
                        ),
                      );
                    }),
                  ),
                  const SizedBox(height: 20),
                  FadeTransition(
                    opacity: _subtitleFade,
                    child: SlideTransition(
                      position: _subtitleOffset,
                      child: const Text(
                        'वीर भोग्या वसुंधरा',
                        style: TextStyle(
                          fontSize: 22,
                          fontStyle: FontStyle.italic,
                          color: Colors.yellowAccent,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),

                  // Premium Carousel
                  SizedBox(
                    height: width * 0.22, // responsive carousel height
                    child: PageView.builder(
                      controller: _pageController,
                      itemCount: _carouselItems.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding:
                          const EdgeInsets.symmetric(horizontal: 10.0),
                          child: _buildPremiumButton(
                              _carouselItems[index], width),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CarouselButtonData {
  final String label;
  final IconData icon;
  final List<Color> gradient;
  _CarouselButtonData(this.label, this.icon, this.gradient);
}

// --------------------------- Register Page ---------------------------

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  String? _name, _email, _password, _confirmPassword, _mobile, _gender;
  DateTime? _dob;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Register"),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(labelText: "Full Name"),
                onSaved: (val) => _name = val,
                validator: (val) =>
                val!.isEmpty ? "Please enter your name" : null,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "Email"),
                keyboardType: TextInputType.emailAddress,
                onSaved: (val) => _email = val,
                validator: (val) =>
                val!.isEmpty ? "Please enter email" : null,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "Password"),
                obscureText: true,
                onSaved: (val) => _password = val,
                validator: (val) =>
                val!.isEmpty ? "Please enter password" : null,
              ),
              TextFormField(
                decoration:
                const InputDecoration(labelText: "Confirm Password"),
                obscureText: true,
                onSaved: (val) => _confirmPassword = val,
                validator: (val) =>
                val!.isEmpty ? "Please confirm password" : null,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "Mobile Number"),
                keyboardType: TextInputType.phone,
                onSaved: (val) => _mobile = val,
              ),
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(labelText: "Gender"),
                items: const [
                  DropdownMenuItem(value: "Male", child: Text("Male")),
                  DropdownMenuItem(value: "Female", child: Text("Female")),
                  DropdownMenuItem(value: "Other", child: Text("Other")),
                ],
                onChanged: (val) => _gender = val,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text("Date of Birth: "),
                  TextButton(
                    child: Text(_dob == null
                        ? "Select DOB"
                        : "${_dob!.day}/${_dob!.month}/${_dob!.year}"),
                    onPressed: () async {
                      final date = await showDatePicker(
                        context: context,
                        initialDate: DateTime(2000),
                        firstDate: DateTime(1900),
                        lastDate: DateTime.now(),
                      );
                      if (date != null) setState(() => _dob = date);
                    },
                  ),
                ],
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    minimumSize: const Size(double.infinity, 50)),
                child: const Text("Submit"),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Registered Successfully")));
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
// hdsvfhvjhvfsd