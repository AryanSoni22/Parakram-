import 'dart:async';
import 'package:flutter/material.dart';

// ---------------- MAIN SOCIAL TAB ----------------
class SocialTab extends StatefulWidget {
  const SocialTab({super.key});

  @override
  State<SocialTab> createState() => _SocialTabState();
}

class _SocialTabState extends State<SocialTab> with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  Timer? _timer;

  late AnimationController _titleAnimationController;
  late Animation<double> _titleScale;

  late AnimationController _iconSlideController;
  late Animation<double> _leftIconOffset;
  late Animation<double> _rightIconOffset;

  late AnimationController _dotPulseController;
  late Animation<double> _dotPulseScale;

  int _expandedIndex = -1;

  final List<String> imageUrls = [
    "https://static.toiimg.com/thumb/msid-121856078,imgsize-1462927,width-400,resizemode-4/121856078.jpg",
    "https://www.ssbcrack.com/wp-content/uploads/2022/07/Indias-Top-5-Toughest-Military-Training-Academies.jpg",
    "https://www.livemint.com/lm-img/img/2023/09/04/original/PTI08-29-2023-000059B-0_1693795169679.jpg",
  ];

  final List<Map<String, dynamic>> activities = [
    {
      "name": "🤝 Volunteer at community events",
      "icon": Icons.volunteer_activism,
      "details": [
        {
          "title": "Blood donation drives",
          "images": [
            "https://pbs.twimg.com/media/Fz7kRWraAAAjgui.jpg",
            "https://pbs.twimg.com/media/DTUYGEqXUAAnFHn.jpg:large",
          ]
        },
        {
          "title": "Local clean-up",
          "images": [
            "https://defence.in/attachments/eeh0okpvuaay47s-webp.666/",
            "https://www.hindustantimes.com/ht-img/img/2025/04/21/1600x900/ANI-20250420228-0_1745264648921_1745264656810.jpg",
          ]
        },
        {
          "title": "Charity events",
          "images": [
            "https://www.shutterstock.com/editorial/image-editorial/MeTcA108Mfj7gdzcNjMxODg=/indian-army-soldiers-help-people-cross-flooded-1500w-10346198s.jpg",
            "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201306/flood1_660_062413121505.jpg",
          ]
        },
      ]
    },
    {
      "name": "💪 Organize group workouts",
      "icon": Icons.fitness_center,
      "details": [
        {
          "title": "Morning yoga",
          "images": [
            "https://cdn.zeebiz.com/sites/default/files/2024/08/15/312127-1.jpg",
            "https://dograherald.com/wp-content/uploads/2024/06/2b-14.jpg",
            "https://i.ytimg.com/vi/eK9yOtQ-wqU/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBiAyXl2CvkW7_DdbAHZRxRI7EcUQ",
          ]
        },
        {
          "title": "Weekend bootcamp",
          "images": [
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFY45eTCdxP53Os9Lg4Fo3X3qUerx7591yuSIsRTrvEGxiI96qwOZrJzBwIC5sUDmSYw4&usqp=CAU",
          ]
        },
        {
          "title": "Running clubs",
          "images": [
            "https://2.bp.blogspot.com/-eLCittO8dFA/UluVKNj3PCI/AAAAAAAALkc/gubgCInON8c/s1600/INDO-NEPAL-COMBINED-MILITARY-TRAINING-CONCLUDES-AT-PITHORAGARH.jpg",
            "https://static.pib.gov.in/WriteReadData/userfiles/image/IMG-20231210-WA0017IQXB.jpg",
          ]
        },
      ]
    },
    {
      "name": "🎓 Mentor juniors",
      "icon": Icons.school,
      "details": [
        {
          "title": "Training sessions",
          "images": [
            "https://images.unsplash.com/photo-1503676260728-1c00da094a0b",
          ]
        },
        {
          "title": "One-on-one guidance",
          "images": [
            "https://images.unsplash.com/photo-1523240795612-9a054b0db644",
          ]
        },
        {
          "title": "Workshops",
          "images": [
            "https://images.unsplash.com/photo-1551836022-d5d88e9218df",
          ]
        },
      ]
    },
    {
      "name": "⚽ Team sports participation",
      "icon": Icons.sports_soccer,
      "details": [
        {"title": "Football", "images": ["https://images.unsplash.com/photo-1508609349937-5ec4ae374ebf"]},
        {"title": "Basketball", "images": ["https://images.unsplash.com/photo-1517649763962-0c623066013b"]},
        {"title": "Cricket", "images": ["https://images.unsplash.com/photo-1591289002949-08d6c8d3cbb2"]},
      ]
    },
  ];

  @override
  void initState() {
    super.initState();

    // Auto-slide background
    _timer = Timer.periodic(const Duration(seconds: 3), (timer) {
      _currentPage = (_currentPage + 1) % imageUrls.length;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_pageController.hasClients) {
          _pageController.animateToPage(
            _currentPage,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
          );
        }
      });
    });

    // Title animation
    _titleAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _titleScale = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _titleAnimationController, curve: Curves.elasticOut),
    );
    _titleAnimationController.forward();

    // Icons slide animation
    _iconSlideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _leftIconOffset = Tween<double>(begin: -60, end: 0).animate(
      CurvedAnimation(parent: _iconSlideController, curve: Curves.easeInOut),
    );
    _rightIconOffset = Tween<double>(begin: 60, end: 0).animate(
      CurvedAnimation(parent: _iconSlideController, curve: Curves.easeInOut),
    );
    _iconSlideController.forward();

    // Dot pulse animation
    _dotPulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _dotPulseScale = Tween<double>(begin: 1.0, end: 1.3).animate(
      CurvedAnimation(parent: _dotPulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    _titleAnimationController.dispose();
    _iconSlideController.dispose();
    _dotPulseController.dispose();
    super.dispose();
  }

  Widget _buildFloatingBackButton(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        width: 56,
        height: 56,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            colors: [Colors.blueAccent, Colors.greenAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.blueAccent.withOpacity(0.5),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: const Center(
          child: Icon(Icons.arrow_back, color: Colors.white, size: 26),
        ),
      ),
    );
  }

  Widget _buildActivityBlock(Map<String, dynamic> activity, int index) {
    bool isExpanded = _expandedIndex == index;

    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0.2, end: 1.0),
      duration: Duration(milliseconds: 500 + (index * 100)),
      curve: Curves.easeOut,
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, (1 - value) * 20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Timeline dot
                Column(
                  children: [
                    ScaleTransition(
                      scale: _dotPulseScale,
                      child: Container(
                        width: 14,
                        height: 14,
                        decoration: const BoxDecoration(
                          color: Colors.greenAccent,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                    if (index != activities.length - 1)
                      Container(width: 4, height: 80, color: Colors.greenAccent.withOpacity(0.6)),
                  ],
                ),
                const SizedBox(width: 12),

                // Activity card
                Expanded(
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 400),
                    margin: const EdgeInsets.symmetric(vertical: 8),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isExpanded ? Colors.blueAccent : Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: const [
                        BoxShadow(color: Colors.black26, blurRadius: 8, offset: Offset(0, 4)),
                      ],
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                      child: ExpansionTile(
                        initiallyExpanded: isExpanded,
                        onExpansionChanged: (expanded) {
                          setState(() {
                            _expandedIndex = expanded ? index : -1;
                          });
                        },
                        leading: Icon(activity['icon'], color: Colors.white),
                        collapsedIconColor: Colors.white,
                        iconColor: Colors.white,
                        textColor: Colors.white,
                        collapsedTextColor: Colors.white,
                        title: Text(
                          activity['name'],
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.white),
                        ),
                        children: [
                          for (var detail in (activity['details'] as List))
                            ListTile(
                              leading: const Icon(Icons.arrow_forward, color: Colors.white),
                              title: Text(detail['title'], style: const TextStyle(color: Colors.white)),
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => DetailPage(
                                      title: detail['title'],
                                      images: List<String>.from(detail['images']),
                                    ),
                                  ),
                                );
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background slideshow
          PageView.builder(
            controller: _pageController,
            itemCount: imageUrls.length,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) => Image.network(
              imageUrls[index],
              fit: BoxFit.cover,
              height: double.infinity,
              width: double.infinity,
            ),
          ),
          Container(color: Colors.black.withOpacity(0.5)),

          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 20),
                // Animated icons
                Stack(
                  alignment: Alignment.center,
                  children: [
                    AnimatedBuilder(
                      animation: _iconSlideController,
                      builder: (context, child) =>
                          Transform.translate(offset: Offset(_leftIconOffset.value, 0), child: const Icon(Icons.group, size: 40, color: Colors.greenAccent)),
                    ),
                    AnimatedBuilder(
                      animation: _iconSlideController,
                      builder: (context, child) =>
                          Transform.translate(offset: Offset(_rightIconOffset.value, 0), child: const Icon(Icons.handshake, size: 40, color: Colors.greenAccent)),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                // Title
                ScaleTransition(
                  scale: _titleScale,
                  child: const Text(
                    "Social Engagement",
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                      color: Colors.greenAccent,
                      shadows: [Shadow(blurRadius: 12, color: Colors.black45, offset: Offset(2, 2))],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                // Activities
                Expanded(
                  child: ListView.builder(
                    itemCount: activities.length,
                    itemBuilder: (context, index) => _buildActivityBlock(activities[index], index),
                  ),
                ),
              ],
            ),
          ),

          Align(alignment: Alignment.bottomRight, child: Padding(padding: const EdgeInsets.all(16.0), child: _buildFloatingBackButton(context))),
        ],
      ),
    );
  }
}

// ---------------- DETAIL PAGE ----------------
class DetailPage extends StatelessWidget {
  final String title;
  final List<String> images;

  const DetailPage({super.key, required this.title, required this.images});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title), backgroundColor: Colors.deepPurple, centerTitle: true),
      body: GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
        ),
        itemCount: images.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ImagePreviewPage(imageUrl: images[index])),
            ),
            child: Hero(
              tag: images[index],
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.network(images[index], fit: BoxFit.cover),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ---------------- FULL-SCREEN IMAGE PREVIEW ----------------
class ImagePreviewPage extends StatelessWidget {
  final String imageUrl;
  const ImagePreviewPage({super.key, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Center(
          child: Hero(
            tag: imageUrl,
            child: InteractiveViewer(child: Image.network(imageUrl)),
          ),
        ),
      ),
    );
  }
}
