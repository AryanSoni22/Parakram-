import 'dart:async';
import 'package:flutter/material.dart';

class PhysicalTab extends StatefulWidget {
  const PhysicalTab({super.key});

  @override
  State<PhysicalTab> createState() => _PhysicalTabState();
}

class _PhysicalTabState extends State<PhysicalTab> with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  Timer? _timer;

  late AnimationController _titleAnimationController;
  late Animation<double> _titleScale;

  late AnimationController _dumbbellController;
  late Animation<double> _dumbbellLeftOffset;
  late Animation<double> _dumbbellRightOffset;

  late AnimationController _dotPulseController;
  late Animation<double> _dotPulseScale;

  int _expandedIndex = -1;

  final List<String> imageUrls = [
    'https://images.unsplash.com/photo-1575419268007-a9a5e6b1ce0b?q=80&w=2000&auto=format&fit=crop',
    'https://api.army.mil/e2/c/images/2025/05/14/52d70ae6/original.jpg',
    'https://hinddefenceacademy.com/wp-content/uploads/2024/04/post-2.jpg',
    'https://media.istockphoto.com/id/902651248/photo/redhead-male-and-brunette-female-military-swat-security-anti-terror-duo-crawling-together.jpg?s=612x612&w=0&k=20&c=-OmyYUkJdQdcKUGvcqti4USynWLUAYQHSwB4Svcjay8='
  ];

  final List<Map<String, dynamic>> activities = const [
    {
      "name": "Weight Training",
      "icon": Icons.fitness_center,
      "exercises": [
        {"name": "Bench Press", "media": ["https://training.fit/wp-content/uploads/2018/11/bankdruecken-flachbank-langhantel.png"]},
        {"name": "Squats", "media": ["https://training.fit/wp-content/uploads/2020/03/kniebeugen-langhantel-800x448.png"]},
        {
          "name": "Deadlifts",
          "media": [
            "https://training.fit/wp-content/uploads/2020/02/deadlift-kreuzheben-800x448.png",
            "https://images03.military.com/sites/default/files/styles/full/public/2020-06/army-fitness-test-weights-3000.jpg"
          ]
        },
      ]
    },
    {
      "name": "Cardio",
      "icon": Icons.directions_run,
      "exercises": [
        {"name": "Running", "media": ["https://cdn.dribbble.com/userupload/23154690/file/original-c01de45d5eb4806a8fee7a3176c343cd.gif"]},
        {"name": "Cycling", "media": ["https://cdn.dribbble.com/userupload/22211228/file/original-59460cb29535e40317ae8fc6f3961150.gif"]},
        {"name": "Skipping", "media": ["https://cdn.dribbble.com/userupload/21885589/file/original-79ff24243d5474150794bc18399e276d.gif"]},
      ]
    },
    {
      "name": "Weight Loss",
      "icon": Icons.local_fire_department,
      "exercises": [
        {"name": "HIIT","media":["https://mir-s3-cdn-cf.behance.net/project_modules/hd/8e6882139723411.6234db3ba9669.gif"]},
        {"name": "Yoga", "media": ["https://i.makeagif.com/media/4-21-2016/3P1et-.gif"]},
        {"name": "Swimming", "media": ["https://i.pinimg.com/originals/d7/ca/83/d7ca8369da63fe5b54b40ada5aeee357.gif"]},
      ]
    },
  ];

  @override
  void initState() {
    super.initState();

    _timer = Timer.periodic(const Duration(seconds: 3), (timer) {
      _currentPage = (_currentPage + 1) % imageUrls.length;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_pageController.hasClients) {
          _pageController.animateToPage(
            _currentPage,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
          );
        }
      });
    });

    _titleAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _titleScale = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _titleAnimationController, curve: Curves.elasticOut),
    );
    _titleAnimationController.forward();

    _dumbbellController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _dumbbellLeftOffset = Tween<double>(begin: -60, end: 0).animate(
      CurvedAnimation(parent: _dumbbellController, curve: Curves.easeInOut),
    );
    _dumbbellRightOffset = Tween<double>(begin: 60, end: 0).animate(
      CurvedAnimation(parent: _dumbbellController, curve: Curves.easeInOut),
    );
    _dumbbellController.forward();

    _dotPulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _dotPulseScale = Tween<double>(begin: 1.0, end: 1.3).animate(
      CurvedAnimation(parent: _dotPulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    _titleAnimationController.dispose();
    _dumbbellController.dispose();
    _dotPulseController.dispose();
    super.dispose();
  }

  void _openExerciseFullScreen(String title, List<String> mediaUrls) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ExerciseFullScreenPage(title: title, mediaUrls: mediaUrls),
      ),
    );
  }

  Widget _buildFloatingBackButton(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        width: 56,
        height: 56,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            colors: [Colors.green, Colors.greenAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(color: Colors.green.withOpacity(0.5), blurRadius: 12, offset: const Offset(0, 4)),
          ],
        ),
        child: const Center(
          child: Icon(Icons.arrow_back, color: Colors.white, size: 26),
        ),
      ),
    );
  }

  Widget _buildActivityBlock(Map<String, dynamic> activity, int index) {
    bool isExpanded = _expandedIndex == index;

    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0.2, end: 1.0),
      duration: Duration(milliseconds: 500 + (index * 100)),
      curve: Curves.easeOut,
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, (1 - value) * 20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: [
                    ScaleTransition(
                      scale: _dotPulseScale,
                      child: Container(
                        width: 14,
                        height: 14,
                        decoration: const BoxDecoration(
                          color: Colors.greenAccent,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                    if (index != activities.length - 1)
                      Container(
                        width: 4,
                        height: 80,
                        color: Colors.greenAccent.withOpacity(0.6),
                      ),
                  ],
                ),
                const SizedBox(width: 12),

                Expanded(
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 400),
                    margin: const EdgeInsets.symmetric(vertical: 8),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isExpanded ? Colors.green : Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        )
                      ],
                    ),
                    child: Theme(
                      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                      child: ExpansionTile(
                        initiallyExpanded: isExpanded,
                        onExpansionChanged: (expanded) {
                          setState(() {
                            _expandedIndex = expanded ? index : -1;
                          });
                        },
                        leading: Icon(activity['icon'], color: Colors.white),
                        collapsedIconColor: Colors.white,
                        iconColor: Colors.white,
                        textColor: Colors.white,
                        collapsedTextColor: Colors.white,
                        title: Text(
                          activity['name'],
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: Colors.white,
                          ),
                        ),
                        children: [
                          for (int i = 0; i < (activity['exercises'] as List).length; i++)
                            TweenAnimationBuilder(
                              tween: Tween<double>(begin: 0, end: 1),
                              duration: Duration(milliseconds: 300 + (i * 200)),
                              builder: (context, double animValue, child) {
                                final exercise = activity['exercises'][i];
                                return Opacity(
                                  opacity: animValue,
                                  child: Transform.translate(
                                    offset: Offset((1 - animValue) * 20, 0),
                                    child: ListTile(
                                      onTap: () => _openExerciseFullScreen(exercise['name'], List<String>.from(exercise['media'])),
                                      leading: const Icon(Icons.check_circle, color: Colors.white),
                                      title: Text(
                                        exercise['name'],
                                        style: const TextStyle(color: Colors.white),
                                      ),
                                      trailing: const Icon(Icons.play_circle_fill, color: Colors.white70),
                                    ),
                                  ),
                                );
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView.builder(
            controller: _pageController,
            itemCount: imageUrls.length,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) => Image.network(
              imageUrls[index],
              fit: BoxFit.cover,
              height: double.infinity,
              width: double.infinity,
            ),
          ),

          Container(color: Colors.black.withOpacity(0.5)),

          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 20),

                Stack(
                  alignment: Alignment.center,
                  children: [
                    AnimatedBuilder(
                      animation: _dumbbellController,
                      builder: (context, child) => Transform.translate(
                        offset: Offset(_dumbbellLeftOffset.value, 0),
                        child: Image.network(
                          'https://cdn-icons-png.flaticon.com/512/61/61154.png',
                          width: 40,
                          height: 40,
                        ),
                      ),
                    ),
                    AnimatedBuilder(
                      animation: _dumbbellController,
                      builder: (context, child) => Transform.translate(
                        offset: Offset(_dumbbellRightOffset.value, 0),
                        child: Image.network(
                          'https://cdn-icons-png.flaticon.com/512/61/61154.png',
                          width: 40,
                          height: 40,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                ScaleTransition(
                  scale: _titleScale,
                  child: const Text(
                    "Physical Enhancement",
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                      color: Colors.greenAccent,
                      shadows: [
                        Shadow(
                          blurRadius: 12,
                          color: Colors.black45,
                          offset: Offset(2, 2),
                        )
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                Expanded(
                  child: ListView.builder(
                    itemCount: activities.length,
                    itemBuilder: (context, index) => _buildActivityBlock(activities[index], index),
                  ),
                ),
              ],
            ),
          ),

          Align(
            alignment: Alignment.bottomRight,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: _buildFloatingBackButton(context),
            ),
          ),
        ],
      ),
    );
  }
}

/// FULLSCREEN Exercise Page (swipe gallery)
class ExerciseFullScreenPage extends StatefulWidget {
  final String title;
  final List<String> mediaUrls;

  const ExerciseFullScreenPage({super.key, required this.title, required this.mediaUrls});

  @override
  State<ExerciseFullScreenPage> createState() => _ExerciseFullScreenPageState();
}

class _ExerciseFullScreenPageState extends State<ExerciseFullScreenPage> {
  int _currentIndex = 0;
  final PageController _pageController = PageController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                const SizedBox(height: 20),
                Text(
                  widget.title,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.greenAccent,
                  ),
                ),
                const SizedBox(height: 20),
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    itemCount: widget.mediaUrls.length,
                    onPageChanged: (index) {
                      setState(() => _currentIndex = index);
                    },
                    itemBuilder: (context, index) {
                      return Center(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Image.network(
                            widget.mediaUrls[index],
                            fit: BoxFit.contain,
                            height: 350,
                            width: double.infinity,
                            loadingBuilder: (context, child, progress) {
                              if (progress == null) return child;
                              return const Center(child: CircularProgressIndicator(color: Colors.greenAccent));
                            },
                            errorBuilder: (context, error, stackTrace) =>
                            const Icon(Icons.broken_image, size: 80, color: Colors.redAccent),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    widget.mediaUrls.length,
                        (index) => Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: _currentIndex == index ? 12 : 8,
                      height: _currentIndex == index ? 12 : 8,
                      decoration: BoxDecoration(
                        color: _currentIndex == index ? Colors.greenAccent : Colors.white30,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
            Positioned(
              top: 16,
              left: 16,
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: const CircleAvatar(
                  backgroundColor: Colors.green,
                  child: Icon(Icons.arrow_back, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
