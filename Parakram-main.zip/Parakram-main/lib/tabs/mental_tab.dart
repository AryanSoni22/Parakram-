import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class MentalTab extends StatefulWidget {
  const MentalTab({super.key});

  @override
  State<MentalTab> createState() => _MentalTabState();
}

class _MentalTabState extends State<MentalTab> with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  Timer? _timer;

  late AnimationController _titleAnimationController;
  late Animation<double> _titleScale;

  late AnimationController _iconSlideController;
  late Animation<double> _leftIconOffset;
  late Animation<double> _rightIconOffset;

  late AnimationController _dotPulseController;
  late Animation<double> _dotPulseScale;

  int _expandedIndex = -1;

  final List<String> imageUrls = [
    "https://www.ssbcrack.com/wp-content/uploads/2021/11/IMA-POP-11-Dec-2021-1068x601.png",
    "https://www.ssbcrack.com/wp-content/uploads/2021/11/IMA-POP-11-Dec-2021-1068x601.png",
    "https://www.ssbcrack.com/wp-content/uploads/2021/11/IMA-POP-11-Dec-2021-1068x601.png",
  ];

  final List<Map<String, dynamic>> activities = [
    {
      "name": "📚 Recommended Books",
      "icon": Icons.menu_book,
      "details": [
        {
          "title": "Bhagavad Gita",
          "description": "A spiritual guide to self-realization and duty.",
          "pdfUrl": "https://ignca.gov.in/Asi_data/279.pdf",
          "imageUrl":
          "https://archive.org/services/img/in.gov.ignca.279/full/pct:200/0/default.jpg",
        },
        {
          "title": "Meditations - Marcus Aurelius",
          "description": "Philosophical reflections by the Roman Emperor.",
          "pdfUrl":
          "https://archive.org/download/meditationsmarcusaurelius/meditations.pdf",
          "imageUrl":
          "https://m.media-amazon.com/images/I/717Y82GZwWL._UF1000,1000_QL80_.jpg",
        },
        {
          "title": "The Art of War - Sun Tzu",
          "description": "Ancient Chinese strategy and tactics.",
          "pdfUrl":
          "https://www.gutenberg.org/files/132/132-h/132-h.htm", // free eBook
          "imageUrl":
          "https://cdn.penguin.co.in/wp-content/uploads/2022/06/9780143455554.jpg",
        },
      ]
    },
    {
      "name": "🎵 Suggested Songs",
      "icon": Icons.music_note,
      "details": [
        {
          "title": "National Anthem",
          "description": "The prideful anthem of the nation.",
        },
        {
          "title": "Army Songs",
          "description": "Songs to boost morale and unity.",
        },
        {
          "title": "Motivational Instrumentals",
          "description": "Instrumental tracks for motivation and focus.",
        },
      ]
    },
  ];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 3), (timer) {
      _currentPage = (_currentPage + 1) % imageUrls.length;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_pageController.hasClients) {
          _pageController.animateToPage(
            _currentPage,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
          );
        }
      });
    });

    _titleAnimationController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200));
    _titleScale = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
          parent: _titleAnimationController, curve: Curves.elasticOut),
    );
    _titleAnimationController.forward();

    _iconSlideController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    _leftIconOffset = Tween<double>(begin: -60, end: 0).animate(
      CurvedAnimation(parent: _iconSlideController, curve: Curves.easeInOut),
    );
    _rightIconOffset = Tween<double>(begin: 60, end: 0).animate(
      CurvedAnimation(parent: _iconSlideController, curve: Curves.easeInOut),
    );
    _iconSlideController.forward();

    _dotPulseController = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _dotPulseScale = Tween<double>(begin: 1.0, end: 1.3).animate(
      CurvedAnimation(parent: _dotPulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    _titleAnimationController.dispose();
    _iconSlideController.dispose();
    _dotPulseController.dispose();
    super.dispose();
  }

  Widget _buildFloatingBackButton(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        width: 56,
        height: 56,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            colors: [Colors.purpleAccent, Colors.deepPurple],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.purpleAccent.withOpacity(0.5),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: const Center(
          child: Icon(Icons.arrow_back, color: Colors.white, size: 26),
        ),
      ),
    );
  }

  Widget _buildActivityBlock(Map<String, dynamic> activity, int index) {
    bool isExpanded = _expandedIndex == index;
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0.2, end: 1.0),
      duration: Duration(milliseconds: (500 + (index * 100)).toInt()),
      curve: Curves.easeOut,
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, (1 - value) * 20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: [
                    ScaleTransition(
                      scale: _dotPulseScale,
                      child: Container(
                        width: 14,
                        height: 14,
                        decoration: const BoxDecoration(
                            color: Colors.purpleAccent, shape: BoxShape.circle),
                      ),
                    ),
                    if (index != activities.length - 1)
                      Container(
                          width: 4,
                          height: 80,
                          color: Colors.purpleAccent.withOpacity(0.6)),
                  ],
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 400),
                    margin: const EdgeInsets.symmetric(vertical: 8),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isExpanded
                          ? Colors.deepPurple
                          : Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: const [
                        BoxShadow(
                            color: Colors.black26,
                            blurRadius: 8,
                            offset: Offset(0, 4)),
                      ],
                    ),
                    child: Theme(
                      data: Theme.of(context)
                          .copyWith(dividerColor: Colors.transparent),
                      child: ExpansionTile(
                        initiallyExpanded: isExpanded,
                        onExpansionChanged: (expanded) {
                          setState(() {
                            _expandedIndex = expanded ? index : -1;
                          });
                        },
                        leading: Icon(activity['icon'], color: Colors.white),
                        collapsedIconColor: Colors.white,
                        iconColor: Colors.white,
                        textColor: Colors.white,
                        collapsedTextColor: Colors.white,
                        title: Text(activity['name'],
                            style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                                color: Colors.white)),
                        children: [
                          for (var detail in (activity['details'] as List)) ...[
                            TweenAnimationBuilder(
                              tween: Tween<double>(begin: 0, end: 1),
                              duration: Duration(
                                  milliseconds: (300 +
                                      (activity['details']
                                          .indexOf(detail) *
                                          200))
                                      .toInt()),
                              builder: (context, double animValue, child) {
                                return Opacity(
                                  opacity: animValue,
                                  child: Transform.translate(
                                    offset: Offset((1 - animValue) * 20, 0),
                                    child: ListTile(
                                      leading: const Icon(
                                          Icons.arrow_forward_ios,
                                          color: Colors.white),
                                      title: Text(detail['title'],
                                          style: const TextStyle(
                                              color: Colors.white)),
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) => DetailPage(
                                              title: detail['title'],
                                              description:
                                              detail['description'],
                                              pdfUrl: detail['pdfUrl'],
                                              imageUrl: detail['imageUrl'],
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                );
                              },
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        PageView.builder(
          controller: _pageController,
          itemCount: imageUrls.length,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) => Image.network(imageUrls[index],
              fit: BoxFit.cover,
              height: double.infinity,
              width: double.infinity),
        ),
        Container(color: Colors.black.withOpacity(0.5)),
        SafeArea(
          child: Column(children: [
            const SizedBox(height: 20),
            Stack(alignment: Alignment.center, children: [
              AnimatedBuilder(
                animation: _iconSlideController,
                builder: (context, child) => Transform.translate(
                  offset: Offset(_leftIconOffset.value, 0),
                  child: const Icon(Icons.self_improvement,
                      size: 40, color: Colors.purpleAccent),
                ),
              ),
              AnimatedBuilder(
                animation: _iconSlideController,
                builder: (context, child) => Transform.translate(
                  offset: Offset(_rightIconOffset.value, 0),
                  child: const Icon(Icons.menu_book,
                      size: 40, color: Colors.purpleAccent),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            ScaleTransition(
              scale: _titleScale,
              child: const Text(
                "Mental Enhancement",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.2,
                  color: Colors.purpleAccent,
                  shadows: [
                    Shadow(
                        blurRadius: 12,
                        color: Colors.black45,
                        offset: Offset(2, 2))
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: activities.length,
                itemBuilder: (context, index) =>
                    _buildActivityBlock(activities[index], index),
              ),
            ),
          ]),
        ),
        Align(
            alignment: Alignment.bottomRight,
            child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: _buildFloatingBackButton(context))),
      ]),
    );
  }
}

class DetailPage extends StatelessWidget {
  final String title;
  final String description;
  final String? pdfUrl;
  final String? imageUrl;

  const DetailPage(
      {super.key,
        required this.title,
        required this.description,
        this.pdfUrl,
        this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title), backgroundColor: Colors.deepPurple),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child:
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              style:
              const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Text(description, style: const TextStyle(fontSize: 16)),
          if (imageUrl != null) ...[
            const SizedBox(height: 24),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(imageUrl!,
                  height: 200, fit: BoxFit.cover),
            ),
          ],
          if (pdfUrl != null) ...[
            const SizedBox(height: 24),
            GestureDetector(
              onTap: () async {
                final Uri url = Uri.parse(pdfUrl!);
                if (await canLaunchUrl(url)) {
                  await launchUrl(url, mode: LaunchMode.externalApplication);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text("Could not open the link")),
                  );
                }
              },
              child: Row(
                children: const [
                  Icon(Icons.arrow_forward, color: Colors.blueAccent),
                  SizedBox(width: 8),
                  Text("Go through this link to read",
                      style: TextStyle(
                          color: Colors.blueAccent, fontSize: 16)),
                ],
              ),
            ),
          ],
        ]),
      ),
    );
  }
}
